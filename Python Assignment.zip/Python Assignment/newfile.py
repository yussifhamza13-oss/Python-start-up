
import random
secret_number=random.randint(1,10)
guess_count=0
guess_limit=3
while guess_count < guess_limit:
    guess=int(input("Guess:"))
    guess_count +=1
    if guess ==secret_number:
        print("dammit,You won!")
        print(secret_number)
        break
  
else:
    print("Sorry,you lost")
    
    
    
      